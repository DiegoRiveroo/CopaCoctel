const SCRIPT_URL = "https://script.google.com/macros/s/AKfycbz5OV0-HzhQFAUm-TrN4E2GcnJ9WiQEirtxG7qxN4ynSuT5bqqZtf6V5eQZstGcbefhLA/exec";

const activeRoundEl = document.getElementById("activeRound");
const votingStatusEl = document.getElementById("votingStatus");
const rankingEl = document.getElementById("ranking");
const drinksGridEl = document.getElementById("drinksGrid");
const drinkSelectEl = document.getElementById("drinkSelect");
const voteForm = document.getElementById("voteForm");
const voteStatus = document.getElementById("voteStatus");
const refreshBtn = document.getElementById("refreshBtn");
const guestProgressEl = document.getElementById("guestProgress");
const guestCodeInput = document.querySelector('input[name="guestCode"]');

async function api(action, payload = {}) {
  const response = await fetch(SCRIPT_URL, {
    method: "POST",
    mode: "cors",
    headers: { "Content-Type": "text/plain;charset=utf-8" },
    body: JSON.stringify({ action, ...payload })
  });
  return response.json();
}

function medal(position) {
  if (position === 1) return "🥇";
  if (position === 2) return "🥈";
  if (position === 3) return "🥉";
  return `#${position}`;
}

function renderRanking(ranking = []) {
  if (!rankingEl) return;
  if (!ranking.length) {
    rankingEl.innerHTML = "<p>Todavía no hay votos.</p>";
    return;
  }

  rankingEl.innerHTML = ranking.map((item, index) => {
    const position = item.position || index + 1;
    return `
      <div class="rank-card">
        <div class="rank-number">${medal(position)}</div>
        <div>
          <div class="rank-name">${item.team || "Equipo"}</div>
          <div class="drink-meta">Mesa ${item.table || ""}</div>
        </div>
        <div class="rank-points">Posición</div>
      </div>
    `;
  }).join("");
}

function renderDrinks(drinks = []) {
  if (!drinksGridEl || !drinkSelectEl) return;
  if (!drinks.length) {
    drinksGridEl.innerHTML = "<p>No hay tragos activos para esta ronda.</p>";
    drinkSelectEl.innerHTML = "";
    return;
  }

  drinkSelectEl.innerHTML = drinks.map(drink => `
    <option value="${drink.id}">${drink.teamName} — ${drink.name}</option>
  `).join("");

  drinksGridEl.innerHTML = drinks.map(drink => `
    <article class="drink-card">
      <h3>${drink.name}</h3>
      <p class="drink-meta">${drink.teamName} · Mesa ${drink.table || ""}</p>
      ${drink.description ? `<p>${drink.description}</p>` : ""}
    </article>
  `).join("");
}

async function loadData() {
  try {
    const result = await api("getState");
    if (!result.ok) {
      if (activeRoundEl) activeRoundEl.textContent = "Error";
      if (votingStatusEl) votingStatusEl.textContent = result.message || "No se pudo cargar.";
      return;
    }

    if (activeRoundEl) activeRoundEl.textContent = result.roundName || result.eventName;
    if (votingStatusEl) votingStatusEl.textContent = result.votingOpen ? "Votación abierta" : "Votación cerrada";

    renderRanking(result.ranking || []);
    renderDrinks(result.drinks || []);
  } catch (error) {
    if (activeRoundEl) activeRoundEl.textContent = "Error de conexión";
    if (votingStatusEl) votingStatusEl.textContent = "Revisa la URL del Apps Script.";
    console.error(error);
  }
}

async function loadGuestProgress() {
  if (!guestCodeInput || !guestProgressEl) return;
  const guestCode = guestCodeInput.value.trim();
  if (!guestCode) {
    guestProgressEl.innerHTML = "";
    return;
  }

  try {
    const result = await api("getGuestProgress", { guestCode });
    if (!result.ok) {
      guestProgressEl.innerHTML = `<p>${result.message}</p>`;
      return;
    }

    const progress = result.progress;
    guestProgressEl.innerHTML = `
      <div class="progress-card">
        <strong>Tu progreso en esta ronda</strong>
        <p>Votaste ${progress.used} de ${progress.total} tragos posibles.</p>
        <p><strong>Ya votaste:</strong> ${progress.voted.length ? progress.voted.join(", ") : "Todavía ninguno"}</p>
        <p><strong>Pendientes:</strong> ${progress.pending.length ? progress.pending.join(", ") : "Ninguno"}</p>
      </div>
    `;
  } catch (error) {
    guestProgressEl.innerHTML = "<p>No se pudo cargar tu progreso.</p>";
    console.error(error);
  }
}

voteForm?.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (voteStatus) voteStatus.textContent = "Enviando voto...";

  const payload = Object.fromEntries(new FormData(voteForm).entries());
  try {
    const result = await api("submitVote", payload);
    if (voteStatus) voteStatus.textContent = result.message || "Voto procesado.";
    if (result.ok) {
      const lastGuestCode = payload.guestCode || "";
      voteForm.reset();
      if (guestCodeInput) guestCodeInput.value = lastGuestCode;
      await loadData();
      await loadGuestProgress();
    }
  } catch (error) {
    if (voteStatus) voteStatus.textContent = "No se pudo enviar el voto.";
    console.error(error);
  }
});

refreshBtn?.addEventListener("click", loadData);
guestCodeInput?.addEventListener("blur", loadGuestProgress);
guestCodeInput?.addEventListener("change", loadGuestProgress);

loadData();
setInterval(loadData, 10000);
